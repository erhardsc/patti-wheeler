<noscript class="ninja-forms-noscript-message">
    <?php echo $message; ?>
</noscript>