Quiz And Survey Master (Formerly Quiz Master Next)
================

Easily and quickly add quizzes, tests, and surveys to your WordPress site.

Feel free to browse the code and make suggestions/requests. Thanks!

## Bugs ##
If you find an issue, let us know [here](https://github.com/fpcorso/quiz_master_next/issues?q=is%3Aopen)!

## Support ##
This is a developer's portal for Quiz And Survey Master and should _not_ be used for support. Please create a support ticket [here](http://quizandsurveymaster.com/contact-us/).
