<?php

die("Error: Unauthorized Access");
?>
