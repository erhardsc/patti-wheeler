<a class="hide thickbox pro-popup" href="#TB_inline?width=400&height=200&inlineId=pro-popup-notice" title="Buy WP Quiz Pro">click</a>
<div id="pro-popup-notice" class="hide">
    <img class="pro-image" src="<?php echo WP_QUIZ_ASSETS_URL . 'image/wp-quiz-pro-small.jpg' ?>"/>
	<h1 id="pro-notice-header">Like WP Quiz Plugin? You will LOVE WP Quiz Pro!</h1>
	<p>New Quiz type Swiper, Show Ads in the quizzes, Countdown Timer, Open graph integration, Player tracking, Force users to Subscribe to see the results and much more.</p>
	<a class="button-primary" href="https://mythemeshop.com/plugins/wp-quiz-pro/">Buy WP Quiz Pro</a>
</div>
