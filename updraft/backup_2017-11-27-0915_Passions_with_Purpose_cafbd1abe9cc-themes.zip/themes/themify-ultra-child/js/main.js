$=jQuery;

$(document).ready(function() {




});